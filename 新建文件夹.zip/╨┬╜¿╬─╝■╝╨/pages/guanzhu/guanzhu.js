// pages/show/show.js
Page({

  data: {
    api:[],
    pagenum : ""
  },
  // onLoad: function (options) {
  //   var that = this;
  //   wx.request({
  //     url: 'http://127.0.0.1:8000/api/star/',
  //     success:function(data){
  //       console.log(data.data)
  //       that.setData({api:data.data})
  //     }
  //   })
  // },

  bind:function(e){
    this.setData({pagenum:e.detail.value});
  },
  check:function(){
    // console.log(this.data.pagenum);
    // wx.request({
    //   url: 'http://127.0.0.1:8000/api/page/',
    //   data:{pagenum: this.data.pagenum},
    //   method:'Get',
    //   header:{
    //     'content-type':'application/json'
    //   },
    //   success:function(res){
    //     console.log(res)
    //   }
    // })
    wx.navigateTo({
      url: '../gzshangchuan/gzshangchuan',
    })
  },
})