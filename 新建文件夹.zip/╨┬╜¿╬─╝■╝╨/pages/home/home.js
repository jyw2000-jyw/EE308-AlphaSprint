let huanfu=false
Page({
  data: {
  guanzhubtn:"",
  kubtn:"",
  pifu:"/image/像素1.png",
  },
  ku:function() {
    wx.navigateTo({
      url: '../ku/ku',
    })
   },
  
   guanzhu:function() {
    wx.navigateTo({
      url: '../guanzhu/guanzhu',
    })
   },
   touxiang:function() {
    wx.navigateTo({
      url: '../gerenkongjian/gerenkongjian',
    })
   },
  click(){
    if (huanfu){
      this.setData({
        pifu:"/image/像素1.png"
      })
      huanfu=false
    }
    else{
      this.setData({
        pifu:"/image/像素2.png"
      })
      huanfu=true
    }
  }

})