// pages/kushangchuan/kushangchuan.js
Page({

  data: {
    list:""
  },


onLoad: function (options) {

  console.log(options)
  },

  onShow: function () {

  },

  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },
hBottom: function () {

  },

  onShareAppMessage: function () {

  }
})