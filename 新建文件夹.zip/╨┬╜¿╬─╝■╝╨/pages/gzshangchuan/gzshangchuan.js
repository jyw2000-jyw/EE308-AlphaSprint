
Page({
  data: {
    api:[],
    num:""
  },
  // onLoad: function (options) {
  //   var that = this;
  //   wx.request({
  //     url: 'http://127.0.0.1:8000/api/commit/',
  //     success:function(data){
  //       console.log(data.data)
  //       that.setData({api:data.data})
  //     }
  //   })
  // },
})