
Page({
  data: {
  datalist:""
  },
  liuyan() {
    wx.navigateTo({
      url: '../kuliuyan/kuliuyan', 
    })
   },
   onLoad:function(){
    var that = this;
    wx.request({
      url: 'http://127.0.0.1:8000/api/get/',
      success:function(data){
        console.log(data.data)
        that.setData({datalist:data.data})
      }
    })
  },
   shangchuanbtn(event) {
    let maliao=event.currentTarget.dataset.maliao;
    wx.navigateTo({
      url:'/pages/kushangchuan/kushangchuan?maliaoaaa='+maliao.name+ "&maliaobbb="+maliao.id+"&maliaoccc="+maliao.created_at+"&maliaoddd="+maliao.language+"&maliaoeee="+maliao.phone+"&maliaofff="+maliao.last
    })
   },
})