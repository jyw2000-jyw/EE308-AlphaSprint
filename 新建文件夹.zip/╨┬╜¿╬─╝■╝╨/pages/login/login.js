Page({
  data: {
  username:"",
  password:""
  },
  zh:function(e){
    this.setData({username:e.detail.value});
  },
  mm:function(e){
    this.setData({password:e.detail.value});
  },
  sub:function(){
    // console.log(this.data.username, this.data.password);
    // wx.request({
    //   url: 'http://127.0.0.1:8000/api/login/',
    //   data:{username: this.data.username, password:this.data.password},
    //   method:'Get',
    //   header:{
    //     'content-type':'application/json'
    //   },
    //   success:function(res){
    //     console.log(res)
        wx.navigateTo({
          url: '../home/home',
        })
  }
})